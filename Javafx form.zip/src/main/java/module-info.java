module com.example.oopsassign2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.oopsassign2 to javafx.fxml;
    exports com.example.oopsassign2;
}