package com.example.oopsassign2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class FormWithBanner extends Application {

    private ArrayList<String> formData = new ArrayList<>();
    private File selectedImageFile = null;

    @Override
    public void start(Stage primaryStage) {

        Label bannerLabel = new Label("Form");
        bannerLabel.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-size: 20px; -fx-alignment: center;");
        bannerLabel.setPrefHeight(50);
        bannerLabel.setMaxWidth(Double.MAX_VALUE);

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label fatherNameLabel = new Label("Father Name:");
        TextField fatherNameField = new TextField();

        Label cityLabel = new Label("City:");
        ComboBox<String> cityComboBox = new ComboBox<>();
        cityComboBox.getItems().addAll("Lahore", "Islamabad", "Karachi");

        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();

        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();

        Label imageLabel = new Label("Image:");
        Button fileChooserButton = new Button("Choose File");
        fileChooserButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select an Image");
            selectedImageFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedImageFile != null) {
                System.out.println("Selected Image: " + selectedImageFile.getAbsolutePath());
            }
        });


        Circle imagePlaceholder = new Circle(50);
        imagePlaceholder.setFill(Color.LIGHTGRAY);


        Label genderLabel = new Label("Gender:");
        RadioButton maleRadio = new RadioButton("Male");
        RadioButton femaleRadio = new RadioButton("Female");
        ToggleGroup genderGroup = new ToggleGroup();
        maleRadio.setToggleGroup(genderGroup);
        femaleRadio.setToggleGroup(genderGroup);

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            // Collect data
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String city = cityComboBox.getValue();
            String address = addressField.getText();
            String email = emailField.getText();
            String gender = maleRadio.isSelected() ? "Male" : (femaleRadio.isSelected() ? "Female" : "Not Selected");

            formData.add("Name: " + name);
            formData.add("Father Name: " + fatherName);
            formData.add("City: " + city);
            formData.add("Address: " + address);
            formData.add("Email: " + email);
            formData.add("Gender: " + gender);

            if (selectedImageFile != null) {
                formData.add("Image: " + selectedImageFile.getAbsolutePath());
            }


            System.out.println("Form Data:");
            formData.forEach(System.out::println);


        });


        VBox formLayout = new VBox(10,
                createRow(nameLabel, nameField),
                createRow(fatherNameLabel, fatherNameField),
                createRow(cityLabel, cityComboBox),
                createRow(addressLabel, addressField),
                createRow(emailLabel, emailField),
                createRow(imageLabel, fileChooserButton)
        );

        HBox genderLayout = new HBox(10, genderLabel, maleRadio, femaleRadio);
        HBox bottomLayout = new HBox(20, submitButton, imagePlaceholder);
        bottomLayout.setAlignment(Pos.CENTER);

        VBox mainLayout = new VBox(15, bannerLabel, formLayout, genderLayout, bottomLayout);
        mainLayout.setPadding(new Insets(15));
        mainLayout.setAlignment(Pos.TOP_CENTER);


        Scene scene = new Scene(mainLayout, 500, 600);
        primaryStage.setTitle("Form with Banner");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private HBox createRow(Label label, Control inputField) {
        HBox row = new HBox(10, label, inputField);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
