import java.net.Socket;
import java.util.ArrayList;

public class MessagingApp {
    private ArrayList<Contact> contacts;
    private ArrayList<Message> messages;
    private Socket socket;
    private Sender sender;
    private Thread receiverThread;

    public MessagingApp(String host, int port) {
        contacts = new ArrayList<>();
        messages = new ArrayList<>();

        contacts.add(new Contact("Qasam", "112"));
        contacts.add(new Contact("Arham", "113"));
        contacts.add(new Contact("Maham", "114"));
        contacts.add(new Contact("Arqam", "115"));
        contacts.add(new Contact("Tiham", "116"));

        try {
            socket = new Socket(host, port);
            sender = new Sender(socket);
            Receiver receiver = new Receiver(socket);
            receiverThread = new Thread(receiver);
            receiverThread.start();
            System.out.println("Connected to server at " + host + ":" + port);
        } catch (Exception e) {
            System.out.println("Failed to connect to server: " + e.getMessage());
        }
    }

    public void addContacts(Contact[] newContacts) {
        for (Contact contact : newContacts) {
            contacts.add(contact);
        }
        System.out.println("Contacts Added Successfully!");
    }

    public void sendMessage(String senderID, String receiverID, String text) {
        if (socket == null || socket.isClosed()) {
            System.out.println("Socket is not connected. Unable to send message.");
            return;
        }
        Message message = new Message(senderID, receiverID, text);
        messages.add(message);
        sender.sendMessage(message.toString());
        System.out.println("Message Sent Successfully!");
    }

    public void viewMessages(String contactName) {
        boolean found = false;
        for (Message message : messages) {
            if (message.getSenderID().equalsIgnoreCase(contactName)) {
                message.setStatus(Message.Status.SEEN);
                System.out.println(message);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No Messages Found For Contact: " + contactName);
        }
    }

    public void displayMessages() {
        if (messages.isEmpty()) {
            System.out.println("No Messages Available.");
            return;
        }
        System.out.println("Messages:");
        for (Message message : messages) {
            System.out.println(message);
            System.out.println("==========");
        }
    }

    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No Contacts Available.");
            return;
        }
        System.out.println("Contacts:");
        for (Contact contact : contacts) {
            System.out.println(contact);
        }
    }

    public void deleteMessages() {
        messages.clear();
        System.out.println("All Messages Deleted.");
    }

    public void closeConnection() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
                System.out.println("Socket connection closed.");
            }
        } catch (Exception e) {
            System.out.println("Error closing socket: " + e.getMessage());
        }
    }
}
