public class Contact {

    String name;
    String contactID;

    public Contact(String name, String contactID) {

        this.name = name;
        this.contactID = contactID;
    }

    public String getName() {

        return name;
    }

    public String getcontactID() {

        return contactID;
    }

    @Override
    public String toString() {

        return "Name : " + name + " | Contact ID : " + contactID;
    }
}
