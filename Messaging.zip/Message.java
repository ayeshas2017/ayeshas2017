import java.time.LocalTime;
import java.time.LocalDate;

public class Message {
    final String senderID;
    final String receiverID;
    final String text;
    final String messageId;

    public enum Status {
        SENT, RECEIVED, SEEN
    }

    Status currentStatus;
    LocalTime timestamp;

    public Message(String senderID, String receiverID, String text) {
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.text = text;
        this.messageId = "@vb" + LocalDate.now();
        this.timestamp = LocalTime.now().withSecond(0).withNano(0);
        this.currentStatus = Status.SENT;
    }

    public void setStatus(Status currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getSenderID() {
        return senderID;
    }

    public String getreceiverID() {
        return receiverID;
    }

    public String gettext() {
        return text;
    }

    public String getMessageId() {
        return messageId;
    }

    public Status getStatus() {
        return currentStatus;
    }

    @Override
    public String toString() {
        return "Sent By : \t" + senderID + "\n" +
                "Received By :" + receiverID + "\n" +
                text + "\n" +
                timestamp + " | " + getStatus() + "\n" +
                "MessageId : " + messageId;
    }
}
